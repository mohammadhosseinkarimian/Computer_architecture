/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/lab/hw6/fourbyte_cache.vhd";
extern char *IEEE_P_1242562249;

int ieee_p_1242562249_sub_1657552908_1035706684(char *, char *, char *);


static void work_a_0793541160_3212880686_p_0(char *t0)
{
    char t7[16];
    char *t1;
    char *t2;
    char *t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    int t12;
    int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    unsigned char t18;
    unsigned char t19;
    unsigned int t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned char t25;
    unsigned char t26;
    char *t27;
    char *t28;

LAB0:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 2088U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((unsigned char *)t1) = (unsigned char)2;
    xsi_set_current_line(53, ng0);
    t1 = (t0 + 2328U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((unsigned char *)t1) = (unsigned char)2;
    xsi_set_current_line(54, ng0);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t1 = (t0 + 1032U);
    t3 = *((char **)t1);
    t4 = (6 - 3);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t3 + t6);
    t8 = (t7 + 0U);
    t9 = (t8 + 0U);
    *((int *)t9) = 3;
    t9 = (t8 + 4U);
    *((int *)t9) = 2;
    t9 = (t8 + 8U);
    *((int *)t9) = -1;
    t10 = (2 - 3);
    t11 = (t10 * -1);
    t11 = (t11 + 1);
    t9 = (t8 + 12U);
    *((unsigned int *)t9) = t11;
    t12 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t1, t7);
    t13 = (t12 - 0);
    t11 = (t13 * 1);
    xsi_vhdl_check_range_of_index(0, 3, 1, t12);
    t14 = (36U * t11);
    t15 = (0 + t14);
    t9 = (t2 + t15);
    t16 = (t0 + 1968U);
    t17 = *((char **)t16);
    t16 = (t17 + 0);
    memcpy(t16, t9, 36U);
    xsi_set_current_line(55, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 1032U);
    t3 = *((char **)t1);
    t4 = (6 - 3);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t3 + t6);
    t8 = (t7 + 0U);
    t9 = (t8 + 0U);
    *((int *)t9) = 3;
    t9 = (t8 + 4U);
    *((int *)t9) = 2;
    t9 = (t8 + 8U);
    *((int *)t9) = -1;
    t10 = (2 - 3);
    t11 = (t10 * -1);
    t11 = (t11 + 1);
    t9 = (t8 + 12U);
    *((unsigned int *)t9) = t11;
    t12 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t1, t7);
    t13 = (t12 - 0);
    t11 = (t13 * 1);
    xsi_vhdl_check_range_of_index(0, 3, 1, t12);
    t14 = (36U * t11);
    t15 = (0 + t14);
    t9 = (t2 + t15);
    t16 = (t0 + 2208U);
    t17 = *((char **)t16);
    t16 = (t17 + 0);
    memcpy(t16, t9, 36U);
    xsi_set_current_line(56, ng0);
    t1 = (t0 + 1968U);
    t2 = *((char **)t1);
    t4 = (35 - 34);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t3 = (t0 + 1032U);
    t8 = *((char **)t3);
    t11 = (6 - 6);
    t14 = (t11 * 1U);
    t15 = (0 + t14);
    t3 = (t8 + t15);
    t19 = 1;
    if (3U == 3U)
        goto LAB8;

LAB9:    t19 = 0;

LAB10:    if (t19 == 1)
        goto LAB5;

LAB6:    t18 = (unsigned char)0;

LAB7:    if (t18 != 0)
        goto LAB2;

LAB4:
LAB3:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 2208U);
    t2 = *((char **)t1);
    t4 = (35 - 34);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t3 = (t0 + 1032U);
    t8 = *((char **)t3);
    t11 = (6 - 6);
    t14 = (t11 * 1U);
    t15 = (0 + t14);
    t3 = (t8 + t15);
    t19 = 1;
    if (3U == 3U)
        goto LAB20;

LAB21:    t19 = 0;

LAB22:    if (t19 == 1)
        goto LAB17;

LAB18:    t18 = (unsigned char)0;

LAB19:    if (t18 != 0)
        goto LAB14;

LAB16:
LAB15:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 2088U);
    t2 = *((char **)t1);
    t18 = *((unsigned char *)t2);
    t19 = (t18 == (unsigned char)3);
    if (t19 != 0)
        goto LAB26;

LAB28:    t1 = (t0 + 2328U);
    t2 = *((char **)t1);
    t18 = *((unsigned char *)t2);
    t19 = (t18 == (unsigned char)3);
    if (t19 != 0)
        goto LAB29;

LAB30:    xsi_set_current_line(69, ng0);
    t1 = xsi_get_transient_memory(32U);
    memset(t1, 0, 32U);
    t2 = t1;
    memset(t2, (unsigned char)4, 32U);
    t3 = (t0 + 3712);
    t8 = (t3 + 56U);
    t9 = *((char **)t8);
    t16 = (t9 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t1, 32U);
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(70, ng0);
    t1 = (t0 + 3776);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t8 = (t3 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB27:    t1 = (t0 + 3632);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(57, ng0);
    t27 = (t0 + 2088U);
    t28 = *((char **)t27);
    t27 = (t28 + 0);
    *((unsigned char *)t27) = (unsigned char)3;
    goto LAB3;

LAB5:    t17 = (t0 + 1968U);
    t21 = *((char **)t17);
    t10 = (35 - 35);
    t22 = (t10 * -1);
    t23 = (1U * t22);
    t24 = (0 + t23);
    t17 = (t21 + t24);
    t25 = *((unsigned char *)t17);
    t26 = (t25 == (unsigned char)3);
    t18 = t26;
    goto LAB7;

LAB8:    t20 = 0;

LAB11:    if (t20 < 3U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t9 = (t1 + t20);
    t16 = (t3 + t20);
    if (*((unsigned char *)t9) != *((unsigned char *)t16))
        goto LAB9;

LAB13:    t20 = (t20 + 1);
    goto LAB11;

LAB14:    xsi_set_current_line(60, ng0);
    t27 = (t0 + 2328U);
    t28 = *((char **)t27);
    t27 = (t28 + 0);
    *((unsigned char *)t27) = (unsigned char)3;
    goto LAB15;

LAB17:    t17 = (t0 + 2208U);
    t21 = *((char **)t17);
    t10 = (35 - 35);
    t22 = (t10 * -1);
    t23 = (1U * t22);
    t24 = (0 + t23);
    t17 = (t21 + t24);
    t25 = *((unsigned char *)t17);
    t26 = (t25 == (unsigned char)3);
    t18 = t26;
    goto LAB19;

LAB20:    t20 = 0;

LAB23:    if (t20 < 3U)
        goto LAB24;
    else
        goto LAB22;

LAB24:    t9 = (t1 + t20);
    t16 = (t3 + t20);
    if (*((unsigned char *)t9) != *((unsigned char *)t16))
        goto LAB21;

LAB25:    t20 = (t20 + 1);
    goto LAB23;

LAB26:    xsi_set_current_line(63, ng0);
    t1 = (t0 + 1968U);
    t3 = *((char **)t1);
    t4 = (35 - 31);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t3 + t6);
    t8 = (t0 + 3712);
    t9 = (t8 + 56U);
    t16 = *((char **)t9);
    t17 = (t16 + 56U);
    t21 = *((char **)t17);
    memcpy(t21, t1, 32U);
    xsi_driver_first_trans_fast_port(t8);
    xsi_set_current_line(64, ng0);
    t1 = (t0 + 3776);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t8 = (t3 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB27;

LAB29:    xsi_set_current_line(66, ng0);
    t1 = (t0 + 2208U);
    t3 = *((char **)t1);
    t4 = (35 - 31);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t3 + t6);
    t8 = (t0 + 3712);
    t9 = (t8 + 56U);
    t16 = *((char **)t9);
    t17 = (t16 + 56U);
    t21 = *((char **)t17);
    memcpy(t21, t1, 32U);
    xsi_driver_first_trans_fast_port(t8);
    xsi_set_current_line(67, ng0);
    t1 = (t0 + 3776);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t8 = (t3 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB27;

}


extern void work_a_0793541160_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0793541160_3212880686_p_0};
	xsi_register_didat("work_a_0793541160_3212880686", "isim/cache_test_isim_beh.exe.sim/work/a_0793541160_3212880686.didat");
	xsi_register_executes(pe);
}
